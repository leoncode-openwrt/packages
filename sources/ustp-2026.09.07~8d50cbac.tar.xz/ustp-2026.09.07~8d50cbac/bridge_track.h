/*****************************************************************************
  This program is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by the Free
  Software Foundation; either version 2 of the License, or (at your option)
  any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc., 59
  Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  The full GNU General Public License is included in this distribution in the
  file called LICENSE.

******************************************************************************/

#ifndef MSTPD_BRIDGE_TRACK_H
#define MSTPD_BRIDGE_TRACK_H

#include "mstp.h"

int bridge_create(int bridge_idx, CIST_BridgeConfig *cfg);
void bridge_delete(int bridge_idx);
int bridge_track_fini(void);

#endif
